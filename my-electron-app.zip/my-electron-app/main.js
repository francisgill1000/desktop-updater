const { app, BrowserWindow, Notification } = require('electron');
const path = require('path');
const { autoUpdater } = require('electron-updater');

app.setAppUserModelId('My Electron App');

// Auto-reload (only in dev)
try {
  require('electron-reload')(__dirname, {
    electron: require(`${__dirname}/node_modules/electron`)
  });
} catch (_) {}

function getIconPath() {
  const isDev = !app.isPackaged;
  return isDev
    ? path.join(__dirname, 'assets', 'icon.png') // dev path
    : path.join(process.resourcesPath, 'assets', 'icon.png'); // after build
}

// Show notification helper (accepts title and message)
function showNotification(title = 'Electron App', body = 'Your app is ready!') {
  new Notification({
    title,
    body,
    icon: getIconPath()
  }).show();
}

function notifyUpdate(downloaded = false) {
  const title = downloaded ? 'Update Ready' : 'Update Available';
  const body = downloaded
    ? 'Click this notification to restart and install the update.'
    : 'Downloading update...';

  const notification = new Notification({ title, body, icon: getIconPath() });

  notification.on('click', () => {
    if (downloaded) {
      autoUpdater.quitAndInstall();
    }
  });

  notification.show();
}

function createWindow() {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      contextIsolation: true
    }
  });

  win.loadFile('index.html');

  win.webContents.on('did-finish-load', () => {
    // Your existing notification on app load
    showNotification('Custom Title', 'This is your custom message.');

    if (!app.isPackaged) {
      // Skip auto-update checks in dev
      return;
    }

    // Check for updates on load
    autoUpdater.checkForUpdates();
  });
}

app.whenReady().then(() => {
  // Listen for update events and notify user
  autoUpdater.on('update-available', () => notifyUpdate(false));
  autoUpdater.on('update-downloaded', () => notifyUpdate(true));

  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});
